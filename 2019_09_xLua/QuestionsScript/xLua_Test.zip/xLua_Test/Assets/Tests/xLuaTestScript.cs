﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XLua;
using XLuaTest;
using System;

[LuaCallCSharp]
public class xLuaTestScript : MonoBehaviour
{
    public TextAsset luaScript;
    private LuaTable scriptEnv;
    internal static LuaEnv luaEnv = new LuaEnv(); //all lua behaviour shared one luaenv only!
    private Action luaFunc;
    
    void OnGUI()
    {
        if (GUI.Button(new Rect(10, 10, 150, 100), "Reload Lua Text")) {
            TestStart();
            //luaEnv.DoString(luaScript.text, "LuaTestScript", scriptEnv);
        }
    }
    
    // Start is called before the first frame update
    void Awake()
    {
        scriptEnv = luaEnv.NewTable();

        // 为每个脚本设置一个独立的环境，可一定程度上防止脚本间全局变量、函数冲突
        LuaTable meta = luaEnv.NewTable();
        meta.Set("__index", luaEnv.Global);
        scriptEnv.SetMetaTable(meta);
        meta.Dispose();
        luaEnv.DoString(luaScript.text, "TestLuaCode", scriptEnv);
        scriptEnv.Get("TestWrite", out luaFunc);
    }

    void TestStart() {
        luaEnv.DoString(luaScript.text, "TestLuaCode", scriptEnv);
        scriptEnv.Get("TestWrite", out luaFunc);

        if (luaFunc != null)
        {
            luaFunc();
        }
    }

    public void TestHelloWorld() { 
        luaEnv = new LuaEnv();
        luaEnv.DoString("CS.UnityEngine.Debug.Log('hello world')");
        luaEnv.Dispose();
    }

    public void TestFuncOnLua() {
        luaEnv = new LuaEnv();
        LuaTable scriptEnv = luaEnv.NewTable();
        LuaTable meta = luaEnv.NewTable();
        Action overrideAction;
        
        meta.Set("__index", luaEnv.Global);
        scriptEnv.SetMetaTable(meta);
        meta.Dispose();

        scriptEnv.Set("self", this);
        luaEnv.DoString(luaScript.text, "LuaTestScript", scriptEnv);

        Action luaAwake = scriptEnv.Get<Action>("awake");
        scriptEnv.Get("start", out overrideAction);

        if (luaAwake != null)
        {
            luaAwake();
        }
    }

    public void TestLuaFixWrongParams() {

    }
}

[LuaCallCSharp]
public class BaseCal {
    private int _cal_a;
    private int _cal_b;
    
    public BaseCal( int cal_a, int cal_b ) {
        _cal_a = cal_a;
        _cal_b = cal_b;
    }

    public int GetValue() {
        return _cal_a * _cal_b;
    }
}
